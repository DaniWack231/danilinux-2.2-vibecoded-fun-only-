/* Danilinux 2.2 — Calamares installation slideshow
 * Based on the Calamares example / Debian slideshow (GPL-2.0+)
 */

import QtQuick 2.0;
import calamares.slideshow 1.0;

Presentation
{
    id: presentation

    Timer {
        interval: 9000
        repeat: true
        onTriggered: presentation.goToNextSlide()
    }

    Slide {
        Image {
            id: background1
            source: "slide1.jpg"
            width: 467; height: 263
            fillMode: Image.PreserveAspectCrop
            anchors.centerIn: parent
        }
        Text {
            anchors.horizontalCenter: background1.horizontalCenter
            anchors.top: background1.bottom
            text: qsTr("Welcome to Danilinux 2.2.<br/>" +
                  "The Aero-flavoured desktop you know and love.")
            wrapMode: Text.WordWrap
            width: 600
            horizontalAlignment: Text.Center
        }
    }

    Slide {
        Image {
            id: background2
            source: "slide2.jpg"
            width: 467; height: 263
            fillMode: Image.PreserveAspectCrop
            anchors.centerIn: parent
        }
        Text {
            anchors.horizontalCenter: background2.horizontalCenter
            anchors.top: background2.bottom
            text: qsTr("Google Chrome is the default browser,<br/>" +
                  "and Steam is pre-installed for all your games.")
            wrapMode: Text.WordWrap
            width: 600
            horizontalAlignment: Text.Center
        }
    }

    Slide {
        Image {
            id: background3
            source: "slide3.jpg"
            width: 467; height: 263
            fillMode: Image.PreserveAspectCrop
            anchors.centerIn: parent
        }
        Text {
            anchors.horizontalCenter: background3.horizontalCenter
            anchors.top: background3.bottom
            text: qsTr("Wine is built in: run Plants vs. Zombies,<br/>" +
                  "Peggle and other Windows classics.")
            wrapMode: Text.WordWrap
            width: 600
            horizontalAlignment: Text.Center
        }
    }

    Slide {
        Image {
            id: background4
            source: "slide4.jpg"
            width: 467; height: 263
            fillMode: Image.PreserveAspectCrop
            anchors.centerIn: parent
        }
        Text {
            anchors.horizontalCenter: background4.horizontalCenter
            anchors.top: background4.bottom
            text: qsTr("3D Pinball: Space Cadet — the original —<br/>" +
                  "plus SuperTux, Pac-Man and friends, preinstalled.")
            wrapMode: Text.WordWrap
            width: 600
            horizontalAlignment: Text.Center
        }
    }
}
